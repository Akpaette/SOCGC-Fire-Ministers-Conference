// -> app/api/register/route.ts
import { NextResponse } from "next/server"; import { z } from "zod"; import { db, newRef } from "@/lib/server";
const S = z.object({ full_name: z.string().trim().min(3).max(120), email: z.string().trim().toLowerCase().email(),
  phone: z.string().trim().regex(/^\+?[0-9\s-]{7,16}$/), gender: z.enum(["Male", "Female"]), country: z.string().min(2), state: z.string().min(2), city: z.string().min(2),
  church_affiliation: z.string().max(150).optional(), ministerial_designation: z.string().max(100).optional(), ministry_type: z.enum(["SOCGC", "OTHER"]).optional(), branch_name: z.string().trim().max(120).optional(), branch_address: z.string().trim().max(300).optional(),
  consent: z.literal(true), terms: z.literal(true) }).refine(d => d.ministry_type !== "SOCGC" || (d.branch_name && d.branch_address), { message: "Branch and address are required for Seed of Christ Golden Church members" });
export async function POST(req: Request) {
  const p = S.safeParse(await req.json().catch(() => null));
  if (!p.success) return NextResponse.json({ error: "Please check your details.", issues: p.error.flatten().fieldErrors }, { status: 400 });
  const { consent, terms, ...d } = p.data;
  const { data: ex } = await db().from("registrations").select("reference,payment_status").ilike("email", d.email).neq("status", "CANCELLED").maybeSingle();
  if (ex) return NextResponse.json({ state: ex.payment_status === "PAID" ? "ALREADY_CONFIRMED" : "ALREADY_REGISTERED", reference: ex.reference }, { status: 409 }); // retry-safe: reuse the same reference
  const { data, error } = await db().from("registrations").insert({ ...d, reference: newRef(), consent_at: new Date().toISOString() }).select("reference").single();
  if (error) return NextResponse.json({ error: "Could not save. Please try again." }, { status: 500 });
  return NextResponse.json({ reference: data.reference, fee: 10000, bank: "First Bank 3032670285, Solomon Mustapha Oni", whatsapp: "+2349023078075" });
}
