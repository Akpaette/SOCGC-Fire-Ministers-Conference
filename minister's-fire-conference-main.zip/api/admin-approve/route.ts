// -> app/api/admin/approve/route.ts  (admin only: approve or reject a bank transfer; audited)
import { NextResponse } from "next/server"; import { db, requireStaff, newTicket, sendEmail } from "@/lib/server";
export async function POST(req: Request) {
  const a = await requireStaff(req, ["admin"]); if (!a) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { reference, action, note, amount_received, bank_reference } = await req.json();
  const { data: r } = await db().from("registrations").select("id,full_name,email,reference,fee_ngn,payment_status").eq("reference", reference).maybeSingle();
  if (!r) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (action === "reject") {
    if (r.payment_status === "PAID") return NextResponse.json({ error: "Already paid" }, { status: 409 });
    await db().from("registrations").update({ payment_status: "REJECTED", approval_note: note ?? null, approved_by: a.id, approved_at: new Date().toISOString() }).eq("id", r.id);
    await db().from("admin_audit_logs").insert({ administrator_id: a.id, action: "REJECT_PAYMENT", affected_record: r.reference });
    return NextResponse.json({ ok: true });
  }
  if (!Number.isInteger(amount_received) || amount_received < r.fee_ngn) return NextResponse.json({ error: `Amount received must be at least N${r.fee_ngn}` }, { status: 400 });
  const { data: res } = await db().rpc("approve_payment", { p_reg: r.id, p_admin: a.id, p_ticket: newTicket(), p_note: note ?? null });
  if (res?.first_time) {
    await db().from("registrations").update({ amount_received, bank_reference: bank_reference ?? null, proof_received_at: new Date().toISOString() }).eq("id", r.id);
    await sendEmail({ to: r.email, type: "CONFIRMATION", registrationId: r.id, subject: "Your Minister's Fire Conference Registration Is Confirmed — THE MAJOR CALLING",
      html: `<h2>Hello ${r.full_name.replace(/[<>&]/g, "")},</h2><p>Your payment has been received and confirmed. You are registered for the 2026 Fire Ministers Conference, 25th–27th November 2026, at Sebioba National Camp, Lagos–Ibadan Expressway, Lufuape, Ogun State.</p><p>Registration code: <b>${r.reference}</b></p><p>Your QR code on your e-flyer is now verified. Present it, or quote your registration code, at the venue.</p><p>Contact: admin@seedofchrist.org</p>` });
  }
  return NextResponse.json(res);   // an email failure never undoes approval; failed sends stay logged for resend
}
