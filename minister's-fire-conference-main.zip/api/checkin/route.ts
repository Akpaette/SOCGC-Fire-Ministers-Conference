// -> app/api/checkin/route.ts (ushers/admins). Accepts the scanned QR text (URL) or a typed registration code.
import { NextResponse } from "next/server"; import { db, requireStaff } from "@/lib/server";
export async function POST(req: Request) {
  const s = await requireStaff(req); if (!s) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { scan } = await req.json(); const m = String(scan || "").toUpperCase().match(/MFC-[0-9A-F]{10}/);
  if (!m) return NextResponse.json({ outcome: "INVALID" });
  const { data: r } = await db().from("registrations").select("id,payment_status,status").eq("reference", m[0]).maybeSingle();
  if (!r) return NextResponse.json({ outcome: "INVALID" });
  if (r.status === "CANCELLED") return NextResponse.json({ outcome: "CANCELLED" });
  if (r.payment_status !== "PAID") return NextResponse.json({ outcome: "PAYMENT_NOT_VERIFIED" });
  const { data: p } = await db().from("event_passes").select("ticket_number").eq("registration_id", r.id).maybeSingle();
  if (!p) return NextResponse.json({ outcome: "PAYMENT_NOT_VERIFIED" });
  const { data } = await db().rpc("check_in_pass", { p_ticket: p.ticket_number, p_usher: s.id });   // atomic: one usher wins
  return NextResponse.json(data ?? { outcome: "INVALID" });
}
