// -> app/api/admin/payments/route.ts  (admin only: payment tracking data)
import { NextResponse } from "next/server"; import { db, requireStaff } from "@/lib/server";
export async function GET(req: Request) {
  if (!(await requireStaff(req, ["admin"]))) return NextResponse.json({ error: "Unauthorised" }, { status: 401 });
  const { data } = await db().from("registrations").select("reference,full_name,email,phone,state,city,ministry_type,church_affiliation,branch_name,branch_address,fee_ngn,payment_status,status,amount_received,bank_reference,approval_note,approved_at,created_at").order("created_at", { ascending: false }).limit(5000);
  return NextResponse.json({ rows: data ?? [] });
}
